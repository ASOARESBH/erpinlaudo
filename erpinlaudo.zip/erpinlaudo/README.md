# ERP INLAUDO

Sistema ERP completo desenvolvido para a INLAUDO com módulos de CRM, Financeiro e Integrações.

## 📋 Características

### Módulos Implementados

#### 1. CRM (Customer Relationship Management)
- **Cadastro de Clientes**
  - Suporte para CNPJ e CPF
  - Busca automática de dados via API (ReceitaWS e BrasilAPI)
  - Classificação como Lead ou Cliente
  - Campos completos de endereço e contato
  - Sistema de busca e filtros

- **Gerenciamento de Interações**
  - Registro de histórico de contatos
  - Múltiplas formas de contato (telefone, e-mail, presencial, WhatsApp)
  - Agendamento de próximos contatos
  - Sistema de alertas automáticos

#### 2. Financeiro
- **Contas a Receber**
  - Cadastro vinculado a clientes
  - Plano de contas configurável
  - Múltiplas formas de pagamento
  - Sistema de recorrência (parcelamento automático)
  - Controle de status (pendente, pago, vencido, cancelado)
  - Dashboard com totalizadores

- **Contas a Pagar**
  - Cadastro de fornecedores
  - Plano de contas configurável
  - Sistema de recorrência
  - Controle de status
  - Dashboard com totalizadores

#### 3. Integrações
- **Boletos - CORA**
  - Configuração de API Key e Secret
  - Ativação/desativação da integração
  - Documentação integrada

- **Boletos - Stripe**
  - Configuração de Publishable Key e Secret Key
  - Ativação/desativação da integração
  - Documentação integrada

## 🚀 Instalação na HostGator

### Passo 1: Upload dos Arquivos

1. Acesse o **cPanel** da sua conta HostGator
2. Vá em **Gerenciador de Arquivos**
3. Navegue até a pasta `public_html` (ou a pasta do seu domínio)
4. Faça upload de todos os arquivos do sistema

### Passo 2: Criar o Banco de Dados

1. No cPanel, acesse **MySQL® Databases**
2. O banco já deve estar criado: `inlaud99_erpinlaudo`
3. Verifique se o usuário `inlaud99_admin` tem permissões completas

### Passo 3: Importar a Estrutura do Banco

1. No cPanel, acesse **phpMyAdmin**
2. Selecione o banco `inlaud99_erpinlaudo`
3. Clique na aba **SQL**
4. Copie todo o conteúdo do arquivo `database.sql`
5. Cole na área de texto e clique em **Executar**

### Passo 4: Configurar a Conexão

1. Abra o arquivo `config.php`
2. Verifique se as credenciais estão corretas:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'inlaud99_erpinlaudo');
   define('DB_USER', 'inlaud99_admin');
   define('DB_PASS', 'Admin259087@');
   ```

### Passo 5: Ajustar Permissões

1. Certifique-se de que todos os arquivos PHP tenham permissão 644
2. As pastas devem ter permissão 755

### Passo 6: Acessar o Sistema

1. Acesse seu domínio no navegador
2. Exemplo: `http://seudominio.com.br`
3. Você será direcionado para o Dashboard

## 📁 Estrutura de Arquivos

```
erp-inlaudo/
├── config.php                    # Configurações do banco de dados
├── database.sql                  # Estrutura do banco de dados
├── header.php                    # Cabeçalho HTML
├── footer.php                    # Rodapé HTML
├── style.css                     # Estilos CSS
├── index.php                     # Dashboard principal
├── LOGOBRANCA.png               # Logo da INLAUDO
│
├── CRM/
│   ├── clientes.php             # Listagem de clientes
│   ├── cliente_form.php         # Formulário de cliente
│   ├── cliente_delete.php       # Exclusão de cliente
│   ├── api_cnpj.php            # API para buscar dados de CNPJ
│   ├── interacoes.php          # Listagem de interações
│   ├── interacao_form.php      # Formulário de interação
│   └── interacao_delete.php    # Exclusão de interação
│
├── Financeiro/
│   ├── contas_receber.php      # Listagem de contas a receber
│   ├── conta_receber_form.php  # Formulário de conta a receber
│   ├── conta_receber_pagar.php # Marcar como paga
│   ├── conta_receber_delete.php # Exclusão
│   ├── contas_pagar.php        # Listagem de contas a pagar
│   ├── conta_pagar_form.php    # Formulário de conta a pagar
│   ├── conta_pagar_pagar.php   # Marcar como paga
│   └── conta_pagar_delete.php  # Exclusão
│
└── Integrações/
    └── integracoes_boleto.php  # Configuração CORA e Stripe
```

## 🗄️ Estrutura do Banco de Dados

### Tabelas Principais

1. **clientes** - Cadastro de clientes e leads
2. **interacoes** - Histórico de interações com clientes
3. **plano_contas** - Plano de contas (receitas e despesas)
4. **contas_receber** - Contas a receber
5. **contas_pagar** - Contas a pagar
6. **integracoes** - Configurações de integrações (CORA e Stripe)

## 🔧 Funcionalidades Técnicas

### Busca de CNPJ
O sistema utiliza duas APIs para buscar dados de CNPJ:
1. **ReceitaWS** (principal): `https://receitaws.com.br/v1/cnpj/{cnpj}`
2. **BrasilAPI** (fallback): `https://brasilapi.com.br/api/cnpj/v1/{cnpj}`

Se a primeira API falhar, o sistema automaticamente tenta a segunda.

### Sistema de Recorrência
- Ao cadastrar uma conta a receber ou pagar, você pode definir o número de parcelas
- O sistema cria automaticamente todas as parcelas com vencimentos mensais
- Cada parcela é independente e pode ser gerenciada separadamente

### Alertas de Interações
- Ao agendar um próximo contato, o sistema registra a data e hora
- O campo `alerta_enviado` permite implementar notificações futuras

### Controle de Status
- Contas pendentes são automaticamente marcadas como vencidas após a data de vencimento
- O sistema atualiza os status em cada acesso à página de listagem

## 🎨 Personalização

### Cores e Estilos
Edite o arquivo `style.css` para personalizar:
- Cores do tema
- Tamanhos de fonte
- Espaçamentos
- Responsividade

### Logo
Substitua o arquivo `LOGOBRANCA.png` pela logo da sua empresa.

## 📊 Dashboard

O dashboard exibe:
- Total de clientes e leads
- Contas a receber pendentes (quantidade e valor)
- Contas a pagar pendentes (quantidade e valor)
- Interações agendadas para os próximos 7 dias
- Contas vencidas

## 🔐 Segurança

- Todas as entradas são sanitizadas
- Uso de prepared statements (PDO) para prevenir SQL Injection
- Senhas de API armazenadas no banco de dados
- Validação de dados no lado do servidor

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- Desktops
- Tablets
- Smartphones

## 🆘 Suporte

Para dúvidas ou problemas:
1. Verifique se o banco de dados foi importado corretamente
2. Confirme as credenciais em `config.php`
3. Verifique os logs de erro do PHP no cPanel

## 📝 Notas Importantes

1. **Backup Regular**: Faça backup regular do banco de dados
2. **Atualizações**: Mantenha o PHP atualizado (recomendado 7.4+)
3. **SSL**: Configure SSL/HTTPS para maior segurança
4. **Integrações**: Configure as APIs do CORA e Stripe conforme necessário

## 🚀 Próximos Passos Recomendados

1. Implementar sistema de autenticação (login/logout)
2. Adicionar níveis de permissão de usuários
3. Criar relatórios em PDF
4. Implementar envio de e-mails automáticos
5. Adicionar gráficos no dashboard
6. Implementar geração real de boletos via APIs

## 📄 Licença

Sistema desenvolvido exclusivamente para INLAUDO.

---

**Desenvolvido para INLAUDO - Conectando Saúde e Tecnologia**
